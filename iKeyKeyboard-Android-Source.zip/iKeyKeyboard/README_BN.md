# iKey Keyboard — Android IME (Prototype 1.1)

এটি একটি Android Input Method Editor (IME)। ইনস্টল করার পর Android Settings থেকে এটিকে keyboard হিসেবে Enable ও Select করা যায়।

## এই সংস্করণে
- English QWERTY layout এবং আলাদা বাংলা key layout
- English layout-এ phonetic Bangla conversion: `ami` → `আমি`, `tumi` → `তুমি`, `bhalo` → `ভালো`, `bangla` → `বাংলা`
- টাইপ করার সময় transliteration preview; preview-তে tap করলে শব্দটি বাংলায় convert হয়, Space চাপলেও convert হয়
- Light ও Dark theme toggle
- iOS-inspired rounded keycaps, spacing ও neutral palette
- Shift, Backspace, Symbols, Emoji shortcut, Space ও Enter
- Android-এর built-in `sans-serif` / `sans-serif-medium` font ব্যবহার করে iPhone-inspired typography; Apple-এর proprietary San Francisco font অন্তর্ভুক্ত করা হয়নি
- কোনো Internet permission, analytics বা network request নেই

## APK Build
এই সোর্স ZIP-এ APK নেই। Android SDK/Gradle build environment ছাড়া এখানে APK compile করা হয়নি। APK তৈরি করতে:

### GitHub Actions (মোবাইল থেকেও করা যায়)
1. ZIP extract করে ফাইলগুলো GitHub repository-তে upload করুন।
2. GitHub repository → **Actions** → **Build iKey Keyboard APK** খুলুন।
3. **Run workflow** চাপুন (অথবা `main` branch-এ push করুন)।
4. Build সফল হলে workflow run-এর **Artifacts** থেকে `iKeyKeyboard-debug-apk` ডাউনলোড করুন।

### Android Studio
1. Android Studio-তে `iKeyKeyboard` project folder খুলুন।
2. Gradle Sync সম্পন্ন করুন।
3. **Build → Build APK(s)** নির্বাচন করুন।
4. APK: `app/build/outputs/apk/debug/app-debug.apk`।

## ফোনে Enable করা
1. APK install করে iKey Keyboard অ্যাপ খুলুন।
2. **Enable iKey Keyboard** চাপুন এবং Android Settings-এ keyboard enable করুন।
3. অ্যাপে ফিরে **Select iKey Keyboard** চাপুন এবং iKey Keyboard নির্বাচন করুন।
4. কোনো text field-এ keyboard খুলে `EN`/`বাংলা` দিয়ে layout বদলান। English layout-এ `ami` টাইপ করে Space চাপলে `আমি` হবে।

## সীমাবদ্ধতা ও গুরুত্বপূর্ণ নোট
- Phonetic conversion এখন lightweight prototype: কিছু প্রচলিত শব্দের dictionary এবং সাধারণ character mapping আছে; এটি পূর্ণাঙ্গ Avro/Bijoy transliteration engine নয়। সব শব্দ/বানান সঠিক নাও হতে পারে।
- এটি এখনো next-word prediction, cloud suggestions, autocorrect, swipe typing, clipboard history বা voice typing দেয় না।
- তোমার দেওয়া KernelSU/root script `/data/adb/AppleFonts/config.json` লেখে। সাধারণ Android APK sandbox থেকে ওই root-only path পড়তে পারে না; তাই এই keyboard নিজে ওই ফাইল পড়ছে না এবং script-ও চালায় না। নিরাপদে যুক্ত করতে আলাদা, স্পষ্ট root integration লাগবে।
- প্রকৃত Apple San Francisco font Apple-এর মালিকানাধীন; এই প্রজেক্টে Android system sans-serif দিয়ে কাছাকাছি iOS-inspired look রাখা হয়েছে। নিজের বৈধ font file যোগ করলে আলাদা font integration করা যাবে।
- Password বা sensitive field-এ keyboard-এর আচরণ Android/অ্যাপ নির্ধারণ করতে পারে। কোনো keyboard-এ সংবেদনশীল তথ্য টাইপ করার আগে তার নিরাপত্তা সম্পর্কে নিশ্চিত হওয়া উচিত। এই প্রজেক্টে নেটওয়ার্ক/ডেটা সংগ্রহের কোড নেই।

## Build configuration
- Package: `com.sharafat.ikeykeyboard`
- Version: `1.1` (source prototype)
- minSdk: 23; compileSdk: 35
- Gradle: 8.9; Android Gradle Plugin: 8.7.3
