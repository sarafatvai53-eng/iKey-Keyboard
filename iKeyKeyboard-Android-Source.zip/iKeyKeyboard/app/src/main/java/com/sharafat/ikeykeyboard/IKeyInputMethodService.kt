package com.sharafat.ikeykeyboard

import android.inputmethodservice.InputMethodService
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.content.Context
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class IKeyInputMethodService : InputMethodService() {
    private var bangla = false
    private var shifted = false
    private var symbols = false
    private var keyboardRoot: LinearLayout? = null
    private var candidateText: TextView? = null
    private val romanBuffer = StringBuilder()
    private val dark get() = getSharedPreferences("ikey", Context.MODE_PRIVATE).getBoolean("dark", false)
    private val bg get() = if (dark) Color.rgb(35, 35, 39) else Color.rgb(214, 216, 222)
    private val keyBg get() = if (dark) Color.rgb(67, 67, 72) else Color.rgb(250, 250, 252)
    private val specialBg get() = if (dark) Color.rgb(105, 108, 116) else Color.rgb(187, 191, 200)
    private val fg get() = if (dark) Color.WHITE else Color.rgb(30, 30, 34)

    // A compact phonetic map: common digraphs are matched before single letters.
    private val phonetic = linkedMapOf(
        "kh" to "খ", "gh" to "ঘ", "chh" to "ছ", "ch" to "চ", "jh" to "ঝ", "th" to "থ", "dh" to "ধ",
        "ph" to "ফ", "bh" to "ভ", "sh" to "শ", "ss" to "ষ", "ng" to "ঙ", "ny" to "ঞ", "rr" to "ড়",
        "kkh" to "ক্ষ", "ksh" to "ক্ষ", "jn" to "জ্ঞ", "oi" to "ৈ", "ou" to "ৌ", "aa" to "া", "ee" to "ী", "oo" to "ূ",
        "a" to "া", "b" to "ব", "c" to "ক", "d" to "দ", "e" to "ে", "f" to "ফ", "g" to "গ", "h" to "হ",
        "i" to "ি", "j" to "জ", "k" to "ক", "l" to "ল", "m" to "ম", "n" to "ন", "o" to "ো", "p" to "প",
        "q" to "ক", "r" to "র", "s" to "স", "t" to "ত", "u" to "ু", "v" to "ভ", "w" to "ও", "x" to "ক্স",
        "y" to "য়", "z" to "য"
    ).toList().sortedByDescending { it.first.length }

    override fun onCreateInputView(): View {
        keyboardRoot = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(7), dp(4), dp(7))
            setBackgroundColor(bg)
        }
        renderKeyboard()
        return keyboardRoot!!
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        romanBuffer.clear()
        renderKeyboard()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        flushRomanBuffer()
        super.onFinishInputView(finishingInput)
    }

    private fun renderKeyboard() {
        val root = keyboardRoot ?: return
        root.removeAllViews()
        root.setBackgroundColor(bg)

        candidateText = TextView(this).apply {
            text = if (romanBuffer.isNotEmpty()) "${romanBuffer}  →  ${transliterate(romanBuffer.toString())}" else "　"
            textSize = 15f
            gravity = Gravity.CENTER_VERTICAL
            setTextColor(fg)
            setPadding(dp(12), 0, dp(12), 0)
            setOnClickListener { commitPhoneticWord() }
        }
        root.addView(candidateText, LinearLayout.LayoutParams(-1, dp(32)))

        val rows = when {
            symbols -> listOf("1234567890", "@#\$%&-+()", "=*/:;!?'\"")
            bangla -> listOf("ৌৈাীূবহগদজ", "োে্িুপটচজ", "ংমনতসলক", "⇧যরওআএ⌫")
            else -> listOf(
                if (shifted) "QWERTYUIOP" else "qwertyuiop",
                if (shifted) "ASDFGHJKL" else "asdfghjkl",
                "⇧${if (shifted) "ZXCVBNM" else "zxcvbnm"}⌫"
            )
        }
        rows.forEachIndexed { index, row ->
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, dp(3), 0, dp(3)) }
            row.forEach { ch -> addKey(line, ch.toString()) }
            root.addView(line, LinearLayout.LayoutParams(-1, dp(if (index == rows.lastIndex) 51 else 47)))
        }

        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, dp(3), 0, 0) }
        addBottomKey(bottom, if (symbols) "ABC" else "123", 1.05f) { flushRomanBuffer(); symbols = !symbols; renderKeyboard() }
        addBottomKey(bottom, if (bangla) "বাংলা" else "EN", 1.05f) { flushRomanBuffer(); bangla = !bangla; symbols = false; renderKeyboard() }
        addBottomKey(bottom, "☻", 0.75f) { flushRomanBuffer(); currentInputConnection?.commitText("😊", 1) }
        addBottomKey(bottom, "English / বাংলা", 3.7f) { typeSpace() }
        addBottomKey(bottom, ".", 0.7f) { flushRomanBuffer(); currentInputConnection?.commitText(".", 1) }
        addBottomKey(bottom, "↵", 0.95f) { flushRomanBuffer(); sendEnter() }
        root.addView(bottom, LinearLayout.LayoutParams(-1, dp(49)))
    }

    private fun addKey(parent: LinearLayout, label: String) {
        val special = label == "⇧" || label == "⌫"
        val button = Button(this).apply {
            text = label
            textSize = if (label.length > 1) 13f else 19f
            isAllCaps = false
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            setTextColor(fg)
            background = rounded(if (special) specialBg else keyBg)
            minWidth = 0; minimumWidth = 0; minHeight = 0; minimumHeight = 0
            setPadding(0, 0, 0, 0); stateListAnimator = null
            setOnClickListener { handleKey(label) }
        }
        parent.addView(button, LinearLayout.LayoutParams(0, -1, 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
    }

    private fun addBottomKey(parent: LinearLayout, label: String, weight: Float, action: () -> Unit) {
        val button = Button(this).apply {
            text = label
            textSize = if (label.length > 3) 11f else 14f
            isAllCaps = false
            setTextColor(fg)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            background = rounded(specialBg)
            minWidth = 0; minimumWidth = 0; minHeight = 0; minimumHeight = 0
            setPadding(dp(2), 0, dp(2), 0); stateListAnimator = null
            setOnClickListener { action() }
        }
        parent.addView(button, LinearLayout.LayoutParams(0, -1, weight).apply { setMargins(dp(2), 0, dp(2), 0) })
    }

    private fun handleKey(key: String) {
        val ic = currentInputConnection ?: return
        when (key) {
            "⇧" -> { shifted = !shifted; renderKeyboard() }
            "⌫" -> {
                if (romanBuffer.isNotEmpty()) {
                    romanBuffer.deleteCharAt(romanBuffer.length - 1)
                    ic.deleteSurroundingText(1, 0)
                    updateCandidate()
                } else ic.deleteSurroundingText(1, 0)
            }
            else -> {
                val value = if (!bangla && shifted) key.uppercase() else key
                if (!bangla && !symbols && value.length == 1 && value[0].isLetter()) {
                    romanBuffer.append(value.lowercase())
                    ic.commitText(value, 1)
                    updateCandidate()
                } else {
                    flushRomanBuffer()
                    ic.commitText(value, 1)
                }
                if (shifted) { shifted = false; renderKeyboard() }
            }
        }
    }

    private fun typeSpace() {
        if (bangla) currentInputConnection?.commitText(" ", 1)
        else commitPhoneticWord()
    }

    private fun commitPhoneticWord() {
        if (romanBuffer.isEmpty()) {
            currentInputConnection?.commitText(" ", 1)
            return
        }
        val ic = currentInputConnection ?: return
        val original = romanBuffer.toString()
        ic.deleteSurroundingText(original.length, 0)
        ic.commitText(transliterate(original) + " ", 1)
        romanBuffer.clear()
        updateCandidate()
    }

    private fun flushRomanBuffer() {
        if (romanBuffer.isEmpty()) return
        val ic = currentInputConnection
        val original = romanBuffer.toString()
        ic?.deleteSurroundingText(original.length, 0)
        ic?.commitText(transliterate(original), 1)
        romanBuffer.clear()
        updateCandidate()
    }

    private val commonWords = mapOf(
        "ami" to "আমি", "tumi" to "তুমি", "apni" to "আপনি", "amra" to "আমরা",
        "amar" to "আমার", "tomar" to "তোমার", "amake" to "আমাকে", "tomake" to "তোমাকে",
        "bhalo" to "ভালো", "valo" to "ভালো", "kemon" to "কেমন", "acho" to "আছো",
        "achho" to "আছো", "achhi" to "আছি", "bangla" to "বাংলা", "bangladesh" to "বাংলাদেশ",
        "ki" to "কি", "keno" to "কেন", "kothay" to "কোথায়", "hobe" to "হবে",
        "hoy" to "হয়", "na" to "না", "hya" to "হ্যাঁ", "dhonnobad" to "ধন্যবাদ",
        "assalamu" to "আসসালামু", "alaikum" to "আলাইকুম", "allah" to "আল্লাহ",
        "inshallah" to "ইনশাআল্লাহ", "mashallah" to "মাশাআল্লাহ", "dhaka" to "ঢাকা"
    )

    private fun transliterate(input: String): String {
        val normalized = input.lowercase()
        commonWords[normalized]?.let { return it }
        var source = normalized
        val out = StringBuilder()
        while (source.isNotEmpty()) {
            val match = phonetic.firstOrNull { source.startsWith(it.first) }
            if (match != null) {
                val token = match.first
                val value = if (out.isEmpty() && token.length == 1) {
                    when (token) { "a" -> "অ"; "e" -> "এ"; "i" -> "ই"; "o" -> "ও"; "u" -> "উ"; else -> match.second }
                } else match.second
                out.append(value)
                source = source.substring(token.length)
            } else {
                out.append(source.first())
                source = source.drop(1)
            }
        }
        return out.toString()
    }

    private fun updateCandidate() {
        candidateText?.text = if (romanBuffer.isNotEmpty()) "${romanBuffer}  →  ${transliterate(romanBuffer.toString())}   •   Tap to convert" else "　"
    }

    private fun sendEnter() {
        val action = currentInputEditorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION) ?: EditorInfo.IME_ACTION_NONE
        val ic = currentInputConnection ?: return
        if (action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) ic.performEditorAction(action)
        else ic.commitText("\n", 1)
    }

    private fun rounded(color: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(7).toFloat() }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
