package com.sharafat.ikeykeyboard

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.widget.*

class SettingsActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("ikey", Context.MODE_PRIVATE) }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dark = prefs.getBoolean("dark", false)
        val bg = if (dark) Color.rgb(24,24,27) else Color.rgb(245,245,247)
        val fg = if (dark) Color.WHITE else Color.rgb(25,25,28)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 36, 24, 24); setBackgroundColor(bg) }
        val title = TextView(this).apply { text = "iKey Keyboard"; textSize = 29f; typeface = Typeface.DEFAULT_BOLD; setTextColor(fg) }
        val sub = TextView(this).apply { text = "iPhone-inspired • বাংলা + English"; textSize = 15f; setTextColor(fg); setPadding(0,8,0,26) }
        root.addView(title); root.addView(sub)
        val preview = TextView(this).apply {
            text = "Q  W  E  R  T  Y  U  I  O  P\nA  S  D  F  G  H  J  K  L\n⇧  Z  X  C  V  B  N  M  ⌫\n123       বাংলা / EN       space       ↵"
            textSize = 18f; gravity = Gravity.CENTER; setTextColor(if (dark) Color.WHITE else Color.DKGRAY)
            setBackgroundColor(if (dark) Color.rgb(48,48,52) else Color.rgb(225,227,232)); setPadding(12,24,12,24)
        }
        root.addView(preview, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 24 })
        val themeButton = Button(this).apply { text = if (dark) "Switch to Light Mode" else "Switch to Dark Mode"; setOnClickListener { prefs.edit().putBoolean("dark", !prefs.getBoolean("dark", false)).apply(); recreate() } }
        val enableButton = Button(this).apply { text = "1. Enable iKey Keyboard"; setOnClickListener { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) } }
        val chooseButton = Button(this).apply { text = "2. Select iKey Keyboard"; setOnClickListener { (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker() } }
        root.addView(themeButton); root.addView(enableButton); root.addView(chooseButton)
        val note = TextView(this).apply { text = "নোট: Enable করার পর Select iKey Keyboard চাপুন। আপনার টাইপ করা লেখা সংশ্লিষ্ট অ্যাপে যাবে। এই সংস্করণে কোনো নেটওয়ার্ক/ডেটা সংগ্রহের কোড নেই।"; textSize = 14f; setTextColor(fg); setPadding(0,22,0,0) }
        root.addView(note)
        setContentView(ScrollView(this).apply { setBackgroundColor(bg); addView(root) })
    }
}
